package org.acme.getting.started.service;


import org.acme.getting.started.model.ResponseToUser;
import org.acme.getting.started.model.RoleCreationResponse;
import org.acme.getting.started.model.RoleEntity;
import org.acme.getting.started.repository.RoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service
public class RoleServiceImpl{

	@Autowired
	RoleRepository roleRepository;
	
	public RoleCreationResponse saveRoleDetails(RoleEntity roleEntity) {
	
		RoleCreationResponse response = new RoleCreationResponse();
		RoleEntity roleEntityQuery = new RoleEntity();
		RoleEntity roleEntityQueryResponse = new RoleEntity();
		try {
		
			roleEntityQuery = roleRepository.findByRoleName(roleEntity.getRoleName());

		if(roleEntityQuery != null)
		{
			System.out.println("Response is Not Null!!!");
			System.out.println("Response Role: " + roleEntityQuery.getRoleName());
			System.out.println("Request Role" + roleEntity.getRoleName());
			if(roleEntityQuery.getRoleName().equals(roleEntity.getRoleName()))
			{
				System.out.println("get role check!!!!");
				response.setResponseMessage("Role Already Present");
			}
		}
		else {
			
			roleRepository.save(roleEntity);
			roleEntityQueryResponse = roleRepository.findByRoleName(roleEntity.getRoleName());
			response.setRoleCreatioId(roleEntityQueryResponse.getRoleCreatioId());
			response.setUiScreenName(roleEntityQueryResponse.getUiScreenName());
			response.setRoleName(roleEntityQueryResponse.getRoleName());
			response.setCreateCheckBox(roleEntityQueryResponse.getSearchCheckBox());
			response.setAppRejCheckBox(roleEntityQueryResponse.getAppRejCheckBox());
			response.setEditCheckBox(roleEntityQueryResponse.getEditCheckBox());
			response.setSearchCheckBox(roleEntityQueryResponse.getSearchCheckBox());
			response.setStreamName(roleEntityQueryResponse.getStreamName());
			response.setViewCheckBox(roleEntityQueryResponse.getViewCheckBox());
			response.setDescription(roleEntityQueryResponse.getDescription());
			response.setUpdatedBy(roleEntityQueryResponse.getUpdatedBy());
			response.setUpdatedDate(roleEntityQueryResponse.getUpdatedDate());
			response.setResponseMessage("Role Created");
		}
		
		}catch (Exception e) {
			e.printStackTrace();
		}
		return response;
		
		
	}
	
	public ResponseToUser deleteRoleDetails(String roleName) {
		
		ResponseToUser response = new ResponseToUser();
		RoleEntity roleEntityQueryResponse = new RoleEntity();
		
		try {
		roleEntityQueryResponse = roleRepository.findByRoleName(roleName);
		

		if(roleEntityQueryResponse != null)
		{
			System.out.println("Response is Not Null!!!");
			
			roleRepository.deleteById(roleEntityQueryResponse.getRoleCreatioId());
			
			response.setResponseMessage("Role Deleted");
		}
		else {			
			response.setResponseMessage("Role Not Found in DB");
		}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return response;
		
	}


}
