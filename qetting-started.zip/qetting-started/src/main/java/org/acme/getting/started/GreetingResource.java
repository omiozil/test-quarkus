package org.acme.getting.started;


import javax.ws.rs.POST;
import javax.ws.rs.Path;


import org.acme.getting.started.model.RoleCreationResponse;
import org.acme.getting.started.model.RoleEntity;
import org.acme.getting.started.service.RoleServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;


@Path("/hello")
public class GreetingResource {

    
    
    @Autowired
	RoleServiceImpl roleServiceImpl;
	
    @POST
	public RoleCreationResponse addUserByAdmin(RoleEntity roleEntity) {
		
		RoleCreationResponse roleCreationResponse = roleServiceImpl.saveRoleDetails(roleEntity);
		
		return roleCreationResponse;
		
	}
}
