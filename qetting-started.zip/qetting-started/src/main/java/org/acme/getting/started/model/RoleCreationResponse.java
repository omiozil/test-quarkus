package org.acme.getting.started.model;

import java.util.Date;

public class RoleCreationResponse {

	
	private int roleCreatioId;
	private String uiScreenName;
	private Boolean createCheckBox;
	private Boolean editCheckBox;
	private Boolean viewCheckBox;
	private Boolean searchCheckBox;
	private Boolean appRejCheckBox;
	private String roleName;
	private String streamName;
	private String description;
    private String responseMessage;
    private String updatedBy;
    private Date updatedDate;
    
	public int getRoleCreatioId() {
		return roleCreatioId;
	}
	public void setRoleCreatioId(int roleCreatioId) {
		this.roleCreatioId = roleCreatioId;
	}
	public String getUiScreenName() {
		return uiScreenName;
	}
	public void setUiScreenName(String uiScreenName) {
		this.uiScreenName = uiScreenName;
	}
	public Boolean getCreateCheckBox() {
		return createCheckBox;
	}
	public void setCreateCheckBox(Boolean createCheckBox) {
		this.createCheckBox = createCheckBox;
	}
	public Boolean getEditCheckBox() {
		return editCheckBox;
	}
	public void setEditCheckBox(Boolean editCheckBox) {
		this.editCheckBox = editCheckBox;
	}
	public Boolean getViewCheckBox() {
		return viewCheckBox;
	}
	public void setViewCheckBox(Boolean viewCheckBox) {
		this.viewCheckBox = viewCheckBox;
	}
	public Boolean getSearchCheckBox() {
		return searchCheckBox;
	}
	public void setSearchCheckBox(Boolean searchCheckBox) {
		this.searchCheckBox = searchCheckBox;
	}
	public Boolean getAppRejCheckBox() {
		return appRejCheckBox;
	}
	public void setAppRejCheckBox(Boolean appRejCheckBox) {
		this.appRejCheckBox = appRejCheckBox;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public String getStreamName() {
		return streamName;
	}
	public void setStreamName(String streamName) {
		this.streamName = streamName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public Date getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}
    
	
	
	
	
	
}
