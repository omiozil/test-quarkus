package org.acme.getting.started.repository;

import org.acme.getting.started.model.RoleEntity;
import org.springframework.data.jpa.repository.JpaRepository;

/*import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;*/



public interface RoleRepository extends JpaRepository<RoleEntity, Integer> {

	public RoleEntity findByRoleName(String roleName);
	
	public RoleEntity findByroleCreatioId(int roleId);
}
