package org.acme.getting.started.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;



@Entity
@Table(name = "ROLE_CREATION")
public class RoleEntity {

	@Id
	@Column(name="ROLE_CREATION_ID")
	private int roleCreatioId;
	@Column(name="UI_SCREEN_NAME")
	private String uiScreenName;
	@Column(name="CREATECHECKBOX")
	private Boolean createCheckBox;
	@Column(name="EDITCHECKBOX")
	private Boolean editCheckBox;
	@Column(name="VIEWCHECKBOX")
	private Boolean viewCheckBox;
	@Column(name="SEARCHCHECKBOX")
	private Boolean searchCheckBox;
	@Column(name="APPROVE_REJECTCHECKBOX")
	private Boolean appRejCheckBox;
	@Column(name="ROLE_NAME")
	private String roleName;
	@Column(name="STREAM_NAME")
	private String streamName;
	@Column(name="DESCRIPTION")
	private String description;
	
	@Column(name="UPDATEDBY")
	private String updatedBy;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/YYYY")
	@Column(name="UPDATEDDATE")
	private Date updatedDate;
	public int getRoleCreatioId() {
		return roleCreatioId;
	}
	public void setRoleCreatioId(int roleCreatioId) {
		this.roleCreatioId = roleCreatioId;
	}
	public String getUiScreenName() {
		return uiScreenName;
	}
	public void setUiScreenName(String uiScreenName) {
		this.uiScreenName = uiScreenName;
	}
	public Boolean getCreateCheckBox() {
		return createCheckBox;
	}
	public void setCreateCheckBox(Boolean createCheckBox) {
		this.createCheckBox = createCheckBox;
	}
	public Boolean getEditCheckBox() {
		return editCheckBox;
	}
	public void setEditCheckBox(Boolean editCheckBox) {
		this.editCheckBox = editCheckBox;
	}
	public Boolean getViewCheckBox() {
		return viewCheckBox;
	}
	public void setViewCheckBox(Boolean viewCheckBox) {
		this.viewCheckBox = viewCheckBox;
	}
	public Boolean getSearchCheckBox() {
		return searchCheckBox;
	}
	public void setSearchCheckBox(Boolean searchCheckBox) {
		this.searchCheckBox = searchCheckBox;
	}
	public Boolean getAppRejCheckBox() {
		return appRejCheckBox;
	}
	public void setAppRejCheckBox(Boolean appRejCheckBox) {
		this.appRejCheckBox = appRejCheckBox;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public String getStreamName() {
		return streamName;
	}
	public void setStreamName(String streamName) {
		this.streamName = streamName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public Date getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	
}
