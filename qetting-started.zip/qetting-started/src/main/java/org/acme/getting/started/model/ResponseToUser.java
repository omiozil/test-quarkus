package org.acme.getting.started.model;

public class ResponseToUser {

	private String responseMessage;
	
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}		
	
}
